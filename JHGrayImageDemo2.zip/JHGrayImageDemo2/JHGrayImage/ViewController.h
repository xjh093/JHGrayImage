//
//  ViewController.h
//  JHGrayImage
//
//  Created by HaoCold on 2020/11/20.
//  Copyright © 2020 HaoCold. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

