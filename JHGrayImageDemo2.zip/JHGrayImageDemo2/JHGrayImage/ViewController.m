//
//  ViewController.m
//  JHGrayImage
//
//  Created by HaoCold on 2020/11/20.
//  Copyright © 2020 HaoCold. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+AverageColor.h"
#import "UIImage+ImageWithColor.h"
#import "UIImage+InvertedImage.h"
#import "JHGrayDayTestView.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,  strong) NSArray *sectionArray;
@property (nonatomic,  strong) NSMutableArray *dataArray;
@property (nonatomic,  strong) UITableView *tableView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
#if 0
    [self setupView];
#else
    [self xjh_setupViews];
#endif
}

- (void)setupView
{
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = self.view.bounds;
    scrollView.contentSize = CGSizeMake(0, CGRectGetHeight(self.view.bounds)*2);
    [self.view addSubview:scrollView];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), 20);
    label.text = @"机型：真机，iOS 12.5.5";
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:14];
    label.backgroundColor = [UIColor lightGrayColor];
    label.textAlignment = 1;
    [scrollView addSubview:label];
    
    CGFloat x = 0;
    CGFloat y = 0;
    CGFloat w = (CGRectGetWidth(self.view.frame) - 6*5)*0.2;
    
//    UIImage *image = [UIImage imageNamed:@"阿柴"];
    UIImage *image = [UIImage imageNamed:@"rose"];
    
    for (NSInteger i = 0; i < 28; i++) {
        x = (i % 5) * (5 + w) + 5;
        y = (i / 5) * (5 + w) + 50;
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(x, y, w, w);
        imageView.image = image;
        [scrollView addSubview:imageView];

        [JHGrayDayTestView showInView:imageView tag:i];
    }
}

- (void)xjh_setupViews
{
    [self.view addSubview:self.tableView];
    
#if 1
    _sectionArray = @[@"部分滤镜"];
    _dataArray = @[].mutableCopy;
    NSArray *arr1 = @[
        @"CICircularScreen",
        @"CIDotScreen",
        @"CIHatchedScreen",
        @"CILineScreen",
        @"CIMaximumComponent",
        @"CIMinimumComponent",
        @"CIPhotoEffectMono",
        @"CIPhotoEffectNoir",
        @"CIPhotoEffectTonal",
        @"CIComicEffect",
        @"CICrystallize",
        @"CIDepthOfField",
        @"CILineOverlay",
        @"CIPixellate",
        @"CIPointillize",
        @"CIBokehBlur",
        @"CIDiscBlur",
        @"CIGaussianBlur",
        @"CIMorphologyGradient",
        @"CIMotionBlur",
        @"CIZoomBlur",
        @"CIColorInvert",
        @"CIFalseColor",
        @"CIKaleidoscope",
        @"CISepiaTone",
        @"CISpotColor",
        @"CISpotLight",
        @"CIThermal",
        @"CIVignetteEffect",
        @"CIXRay",
        @"CIEdges",
        @"CIPhotoEffectInstant",
        @"CIColorMonochrome",
        @"CILinearToSRGBToneCurve",
        @"CIPhotoEffectChrome",
    ];
    [_dataArray addObject:arr1];
    
#else
    NSArray *categories = @[
        kCICategoryDistortionEffect,
        kCICategoryGeometryAdjustment,
        kCICategoryCompositeOperation,
        kCICategoryHalftoneEffect,
        kCICategoryColorAdjustment,
        kCICategoryColorEffect,
        kCICategoryTransition,
        kCICategoryTileEffect,
        kCICategoryGenerator,
        kCICategoryReduction,
        kCICategoryGradient,
        kCICategoryStylize,
        kCICategorySharpen,
        kCICategoryBlur,
        kCICategoryVideo,
        kCICategoryStillImage,
        kCICategoryInterlaced,
        kCICategoryNonSquarePixels,
        kCICategoryHighDynamicRange,
        kCICategoryBuiltIn,
        kCICategoryFilterGenerator,
    ];
    _sectionArray = categories;
    
    NSLog(@"%@ %@", [UIDevice currentDevice].systemName, [UIDevice currentDevice].systemVersion);
    
    _dataArray = @[].mutableCopy;
    for (NSInteger i = 0; i < categories.count; i++) {
        NSString *name = categories[i];
        
        NSLog(@"=================== Begin[%@]===================", @(i));
        NSLog(@"CICategory name: %@", name);
        
        NSArray *arr = [CIFilter filterNamesInCategory:name];
        for (NSInteger j = 0; j < arr.count; j++) {
            NSLog(@"%@", arr[j]);
        }
        
        NSLog(@"=================== End[%@] ===================", @(i));
        
        [_dataArray addObject:arr];
    }
#endif
}

#pragma mark ---UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _sectionArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *arr = _dataArray[section];
    return arr.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return _sectionArray[section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"resueID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    
    NSArray *arr = _dataArray[indexPath.section];
    
    cell.textLabel.text = [NSString stringWithFormat:@"第%@组，第%@个", @(indexPath.section), @(indexPath.row)];
    cell.detailTextLabel.text = arr[indexPath.row];
    cell.imageView.image = [UIImage imageNamed:@"rose"];
    cell.imageView.layer.borderColor = [UIColor orangeColor].CGColor;
    cell.imageView.layer.borderWidth = 0.5;
    
    cell.accessoryView = ({
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
        imageView.layer.borderColor = [UIColor blueColor].CGColor;
        imageView.layer.borderWidth = 0.5;
        
        @try {
            UIImage *img = [UIImage imageNamed:@"rose"];
            CIImage *image = [[CIImage alloc]initWithImage:img];
            CIFilter *filter = [CIFilter filterWithName:arr[indexPath.row] keysAndValues:kCIInputImageKey, image, nil];
            [filter setDefaults];
            
            CIContext *context = [[CIContext alloc] initWithOptions:nil];
            CIImage *output = [filter outputImage];
            CGImageRef ref = [context createCGImage:output fromRect:[output extent]];
            UIImage *newImage = [UIImage imageWithCGImage:ref];
            CGImageRelease(ref);
            
            imageView.image = newImage;
        } @catch (NSException *exception) {
            
        } @finally {
            
        }

        imageView;
    });
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *arr = _dataArray[indexPath.section];
    NSLog(@"%@", arr[indexPath.row]);
}

- (UITableView *)tableView{
    if (!_tableView) {
        UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:0];
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.rowHeight = 60;
        tableView.sectionHeaderHeight = 30;
        tableView.tableFooterView = [[UIView alloc] init];
        //tableView.showsVerticalScrollIndicator = NO;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView = tableView;
    }
    return _tableView;
}

@end

/* 灰色
 CICircularScreen
 CIDotScreen
 CIHatchedScreen
 CILineScreen
 CIMaximumComponent
 CIMinimumComponent
 CIPhotoEffectMono
 CIPhotoEffectNoir
 CIPhotoEffectTonal
 CIComicEffect
 CICrystallize
 CIDepthOfField
 CILineOverlay
 CIPixellate
 CIPointillize
 CIBokehBlur
 CIDiscBlur
 CIGaussianBlur
 CIMorphologyGradient
 CIMotionBlur
 CIZoomBlur
 CIColorInvert
 CIFalseColor
 CIKaleidoscope
 CISepiaTone
 CISpotColor
 CISpotLight
 CIThermal
 CIVignetteEffect
 CIXRay
 CIEdges
 CIPhotoEffectInstant
 CIColorMonochrome
 CILinearToSRGBToneCurve
 CIPhotoEffectChrome
 */

/*
 //通过改变图像的几何形状来创建3D效果，类似隆起 过滤器组
 NSString * const kCICategoryDistortionEffect;
 //旋转扭曲相关过滤器组
 NSString * const kCICategoryGeometryAdjustment;
 //混合过滤器组 对两个图像进行混合操作
 NSString * const kCICategoryCompositeOperation;
 //一种色调过滤器组 类似报纸风格
 NSString * const kCICategoryHalftoneEffect;
 //颜色过滤器组 调整对比度 亮度等
 NSString * const kCICategoryColorEffect;
 //多个图像源的过滤器
 NSString * const kCICategoryTransition;
 //平铺图像过滤器
 NSString * const kCICategoryTileEffect;
 //滤光类过滤器 通常作为其他过滤器的输入
 NSString * const kCICategoryGenerator;
 //减弱图像数据的过滤器 通常用来进行图像分析
 NSString * const kCICategoryReduction;
 //渐变过滤器
 NSString * const kCICategoryGradient;
 //画像过滤器
 NSString * const kCICategoryStylize;
 //锐化过滤器
 NSString * const kCICategorySharpen;
 //模糊过滤器
 NSString * const kCICategoryBlur;
 //视频图片相关过滤器
 NSString * const kCICategoryVideo;
 //静态图片相关过滤器
 NSString * const kCICategoryStillImage;
 //交叉图像过滤器
 NSString * const kCICategoryInterlaced;
 //非矩形图像上的过滤器
 NSString * const kCICategoryNonSquarePixels;
 //高动态图像的过滤器
 NSString * const kCICategoryHighDynamicRange;
 //CoreImage内置的过滤器
 NSString * const kCICategoryBuiltIn;
 //复合的过滤器
 NSString * const kCICategoryFilterGenerator;
 */
