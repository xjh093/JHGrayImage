//
//  AppDelegate.m
//  JHGrayImage
//
//  Created by HaoCold on 2020/11/20.
//  Copyright © 2020 HaoCold. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


@end
