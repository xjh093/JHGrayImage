#import <UIKit/UIKit.h>


@interface UIImage (AverageColor)

- (UIColor *)averageColor;

@end
