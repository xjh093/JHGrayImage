//
//  ViewController.m
//  JHGrayImage
//
//  Created by HaoCold on 2020/11/20.
//  Copyright © 2020 HaoCold. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+AverageColor.h"
#import "UIImage+ImageWithColor.h"
#import "UIImage+InvertedImage.h"
#import "JHGrayDayTestView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupView];
}

- (void)setupView
{
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), 20);
    //label.text = @"机型：真机，iOS 12.5.5";
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:14];
    label.backgroundColor = [UIColor lightGrayColor];
    label.textAlignment = 1;
    [self.view addSubview:label];
    
    CGFloat x = 0;
    CGFloat y = 0;
    CGFloat w = (CGRectGetWidth(self.view.frame) - 6*5)*0.2;
    
//    UIImage *image = [UIImage imageNamed:@"阿柴"];
    UIImage *image = [UIImage imageNamed:@"rose"];
    
    for (NSInteger i = 0; i < 28; i++) {
        x = (i % 5) * (5 + w) + 5;
        y = (i / 5) * (5 + w) + 50;
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(x, y, w, w);
        imageView.image = image;
        [self.view addSubview:imageView];

        [JHGrayDayTestView showInView:imageView tag:i];
    }
}

@end


