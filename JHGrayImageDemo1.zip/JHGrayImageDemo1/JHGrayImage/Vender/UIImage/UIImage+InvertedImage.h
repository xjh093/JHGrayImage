#import <UIKit/UIKit.h>


@interface UIImage (InvertedImage)

- (UIImage *)invertedImage;

@end
