//
//  MHGrayDay.m
//  JHGrayImage
//
//  Created by HaoCold on 2022/12/2.
//  Copyright © 2022 kmw. All rights reserved.
//

#import "JHGrayDayTestView.h"

@implementation JHGrayDayTestView

+ (void)showInView:(UIView *)view tag:(NSInteger)tag
{
    // 13 及以上的系统，才能使用这个滤镜
    JHGrayDayTestView *v = [[JHGrayDayTestView alloc] initWithFrame:view.bounds];
    v.index = tag;
    //v.layer.zPosition = 1;
    [view addSubview:v];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.translatesAutoresizingMaskIntoConstraints = false;
        self.backgroundColor = [UIColor lightGrayColor];
        self.layer.borderColor = [UIColor orangeColor].CGColor;
        self.layer.borderWidth = 1;
        
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(0, 0, CGRectGetWidth(frame), 10);
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:10];
        label.textAlignment = 1;
        label.tag = 100;
        [self addSubview:label];
    }
    return self;
}

// 最顶层视图，承载滤镜，自身不接收、不拦截任何触摸事件
- (UIView*)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    return nil;
}

- (void)setIndex:(NSInteger)index
{
    _index = index;
    
    UILabel *label = [self viewWithTag:100];
    label.text = @(index).stringValue;
    
    switch (index) {
        case 0: self.layer.compositingFilter = @"additionCompositing"; break;
        case 1: self.layer.compositingFilter = @"colorBlendMode"; break;
        case 2: self.layer.compositingFilter = @"colorBurnBlendMode"; break;
        case 3: self.layer.compositingFilter = @"colorDodgeBlendMode"; break;
        case 4: self.layer.compositingFilter = @"darkenBlendMode"; break;
        case 5: self.layer.compositingFilter = @"differenceBlendMode"; break;
        case 6: self.layer.compositingFilter = @"divideBlendMode"; break;
        case 7: self.layer.compositingFilter = @"exclusionBlendMode"; break;
        case 8: self.layer.compositingFilter = @"hardLightBlendMode"; break;
        case 9: self.layer.compositingFilter = @"hueBlendMode"; break;
        case 10: self.layer.compositingFilter = @"lightenBlendMode"; break;
        case 11: self.layer.compositingFilter = @"linearBurnBlendMode"; break;
        case 12: self.layer.compositingFilter = @"linearDodgeBlendMode"; break;
        case 13: self.layer.compositingFilter = @"luminosityBlendMode"; break;
        case 14: self.layer.compositingFilter = @"maximumCompositing"; break;
        case 15: self.layer.compositingFilter = @"minimumCompositing"; break;
        case 16: self.layer.compositingFilter = @"multiplyBlendMode"; break;
        case 17: self.layer.compositingFilter = @"multiplyCompositing"; break;
        case 18: self.layer.compositingFilter = @"overlayBlendMode"; break;
        case 19: self.layer.compositingFilter = @"pinLightBlendMode"; break;
        case 20: self.layer.compositingFilter = @"screenBlendMode"; break;
        case 21: self.layer.compositingFilter = @"softLightBlendMode"; break;
        case 22: self.layer.compositingFilter = @"sourceAtopCompositing"; break;
        case 23: self.layer.compositingFilter = @"sourceInCompositing"; break;
        case 24: self.layer.compositingFilter = @"sourceOutCompositing"; break;
        case 25: self.layer.compositingFilter = @"sourceOverCompositing"; break;
        case 26: self.layer.compositingFilter = @"subtractBlendMode"; break;
        case 27: self.layer.compositingFilter = @"saturationBlendMode"; break;
        default:
            break;
    }
}

@end
