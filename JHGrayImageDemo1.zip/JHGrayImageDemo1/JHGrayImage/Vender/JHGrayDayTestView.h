//
//  MHGrayDay.h
//  JHGrayImage
//
//  Created by HaoCold on 2022/12/2.
//  Copyright © 2022 kmw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JHGrayDayTestView : UIView

@property (nonatomic,  assign) NSInteger  index;

+ (void)showInView:(UIView *)view tag:(NSInteger)tag;

@end

